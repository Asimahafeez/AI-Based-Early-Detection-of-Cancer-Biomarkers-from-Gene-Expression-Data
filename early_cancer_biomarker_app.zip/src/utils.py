
# helper utilities (placeholder)
def hello():
    return "hello from src.utils"
