
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, roc_auc_score
import joblib

def train(data_path='data/sample_expression.csv', model_out='models/model.pkl', k_features=30):
    os.makedirs(os.path.dirname(model_out), exist_ok=True)
    df = pd.read_csv(data_path)
    X = df.drop(columns=['label'])
    y = df['label'].map({'normal':0, 'cancer':1}).values
    # log transform (counts -> approximate continuous)
    X = np.log2(X + 1)
    # split
    X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.2, random_state=42)
    # feature selection (ANOVA F-test)
    selector = SelectKBest(score_func=f_classif, k=min(k_features, X_train.shape[1]))
    selector.fit(X_train, y_train)
    selected_features = X_train.columns[selector.get_support()].tolist()
    X_train_sel = selector.transform(X_train)
    X_test_sel = selector.transform(X_test)
    # scaling + classifier
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_sel)
    clf = RandomForestClassifier(n_estimators=200, random_state=42)
    clf.fit(X_train_scaled, y_train)
    X_test_scaled = scaler.transform(X_test_sel)
    y_pred = clf.predict(X_test_scaled)
    y_proba = clf.predict_proba(X_test_scaled)[:,1]
    print("Classification report (test set):")
    print(classification_report(y_test, y_pred))
    try:
        print("ROC AUC:", roc_auc_score(y_test, y_proba))
    except Exception as e:
        print("ROC AUC error:", e)
    # save pipeline pieces
    joblib.dump({'scaler': scaler, 'selector': selector, 'clf': clf, 'features': selected_features}, model_out)
    # save features list
    with open(os.path.join(os.path.dirname(model_out), 'selected_features.txt'), 'w') as f:
        f.write('\\n'.join(selected_features))
    print("Saved model and selected features to", model_out)

if __name__ == '__main__':
    train()
