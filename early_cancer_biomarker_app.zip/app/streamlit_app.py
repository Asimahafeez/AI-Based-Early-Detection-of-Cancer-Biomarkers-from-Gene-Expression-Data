
import streamlit as st
import pandas as pd, numpy as np, os, joblib
st.set_page_config(page_title="Early Cancer Biomarker Detector", layout="centered")

st.title("AI-Based Early Detection — Demo")
st.markdown("Upload a gene-expression CSV (samples x genes) with a `label` column optional. "
            "This demo uses a pre-trained model on synthetic data. For real use replace data and retrain.")

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
MODEL_PATH = os.path.join(BASE, 'models', 'model.pkl')

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

model = load_model()

st.sidebar.header("Options")
uploaded = st.file_uploader("Upload CSV (comma-separated) — or use sample", type=['csv'])

if uploaded is None:
    st.info("No file uploaded. Using included sample dataset.")
    df = pd.read_csv(os.path.join(BASE, 'data', 'sample_expression.csv'))
else:
    df = pd.read_csv(uploaded)
st.write("Data preview (first 5 rows):")
st.dataframe(df.head())

if 'label' in df.columns:
    st.write("Label distribution:")
    st.write(df['label'].value_counts())

# prepare input
X = df.drop(columns=[c for c in df.columns if c=='label'], errors='ignore')
# log transform
X = np.log2(X + 1)

selector = model['selector']
clf = model['clf']
scaler = model['scaler']
selected_features = model['features']

# align features: if uploaded file lacks some features, fill zeros and warn
missing = [g for g in selected_features if g not in X.columns]
if missing:
    st.warning(f"Uploaded file missing {len(missing)} selected features. Missing will be filled with zeros. Missing genes example: {missing[:5]}")
    for m in missing:
        X[m] = 0.0
# keep order
X_sel = X[selected_features]
X_scaled = scaler.transform(X_sel.values)
proba = clf.predict_proba(X_scaled)[:,1]
df_out = pd.DataFrame({'sample_index': X_sel.index, 'cancer_risk_score': proba})
st.write("Predictions:")
st.dataframe(df_out.head(20))

# show top contributing features (by feature_importances_ from RF)
importances = clf.feature_importances_
feat_imp = pd.DataFrame({'feature': selected_features, 'importance': importances}).sort_values('importance', ascending=False)
st.write("Top features (by model importance):")
st.dataframe(feat_imp.head(20))

# allow downloading predictions
csv = df_out.to_csv(index=False).encode('utf-8')
st.download_button("Download predictions CSV", csv, file_name='predictions.csv', mime='text/csv')
